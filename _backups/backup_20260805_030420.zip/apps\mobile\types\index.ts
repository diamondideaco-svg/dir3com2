export * from '@/types/domain';
export * from '@/types/result';
